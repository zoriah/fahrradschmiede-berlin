<?php
// Fehleranzeige temporär erzwingen, um Fehler sofort zu sehen
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// 1. Sicherheit & Verbindung laden
require_once('security.php');

try {
    // 2. Datenbank-Verbindung über die sichere PDO-Funktion aufbauen
    $db = getDBConnection();

    // 3. SQL-Query passend zur echten Tabelle 'fahrraeder_import'
    $query = "SELECT 
        Produkt_ID AS produkt_id,
        Fahrrad AS titel,
        Beschreibung AS beschreibung,
        Hauptbild_URL AS bild_url,
        Preis AS preis
    FROM 
        fahrraeder_import
    ORDER BY 
        Fahrrad ASC;";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    // 4. Alle Fahrräder als assoziatives Array abrufen
    $bikes = $stmt->fetchAll(\PDO::FETCH_ASSOC);

    // 5. Erfolgsausgabe als sauberes JSON für Astro
    echo json_encode([
        "status" => "success",
        "count"  => count($bikes),
        "data"   => $bikes
    ], JSON_UNESCAPED_UNICODE);

} catch (\Exception $e) {
    // 6. Fehler abfangen und ausgeben
    error_log("API Fehler in getBikesInfos: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Daten konnten nicht geladen werden.",
        "sql_error" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
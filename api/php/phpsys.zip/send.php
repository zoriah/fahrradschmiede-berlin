<?php
// 1. Sicherheit & CORS
header("Access-Control-Allow-Origin: https://bikeparkberlin.de"); 
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

// 2. Ziel-Konfiguration
$to = "info@bikeparkberlin.de"; 
$sender = "info@bikeparkberlin.de";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // A) Honeypot (Bot-Schutz)
    if (!empty($_POST['botcheck'])) {
        exit(json_encode(["status" => "success", "message" => "Vielen Dank für Ihre Nachricht!"]));
    }

    // B) Daten bereinigen
    $name    = strip_tags(trim($_POST['name'] ?? 'Unbekannt'));
    $email   = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    
    // Header-Injection Schutz (Betreff)
    $subject_user = str_replace(["\r", "\n"], '', strip_tags(trim($_POST['subject'] ?? 'Kein Betreff')));
    
    // Nachricht säubern
    $message = htmlspecialchars(trim($_POST['message'] ?? 'Keine Nachricht'), ENT_QUOTES, 'UTF-8');

    // C) Validierung der E-Mail
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        exit(json_encode([
            "status" => "error", 
            "message" => "Hoppla! Die E-Mail-Adresse scheint nicht ganz korrekt zu sein. Bitte prüfe sie noch einmal."
        ]));
    }

    // D) E-Mail Inhalt zusammenbauen
    $mailSubject = "Kontaktformular: " . $subject_user;
    
    $mailBody  = "NEUE NACHRICHT VOM BIKEPARK-FORMULAR\n";
    $mailBody .= "==================================\n";
    $mailBody .= "VON:      $name\n";
    $mailBody .= "E-MAIL:   $email\n";
    $mailBody .= "BETREFF:  $subject_user\n";
    $mailBody .= "==================================\n\n";
    $mailBody .= "NACHRICHT:\n$message\n";

    // E) Technische Header
    $headers   = "MIME-Version: 1.0" . "\r\n";
    $headers  .= "Content-Type: text/plain; charset=UTF-8" . "\r\n";
    $headers  .= "From: Bikepark Berlin Website <$sender>" . "\r\n";
    $headers  .= "Reply-To: $email" . "\r\n";
    $headers  .= "X-Mailer: PHP/" . phpversion();

    // F) Versand & Antwort-Logik
    if (mail($to, $mailSubject, $mailBody, $headers, "-f " . $sender)) {
        echo json_encode([
            "status" => "success", 
            "message" => "Vielen Dank, $name! Deine Nachricht wurde erfolgreich versendet. Wir melden uns schnellstmöglich bei dir."
        ]);
    } else {
        // Schicke Fehlermeldung für den User
        http_response_code(500);
        echo json_encode([
            "status" => "error", 
            "message" => "Aufgrund einer technischen Serverüberlastung konnte die Nachricht leider nicht gesendet werden. Bitte versuche es später noch einmal oder schreib uns direkt an info@bikeparkberlin.de.\n\nViele Grüße,\nIhr Bikepark Berlin Team"
        ]);
    }

} else {
    // Falls jemand die Datei direkt aufruft
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Methode nicht erlaubt."]);
}
?>